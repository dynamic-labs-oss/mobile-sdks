# Dynamic SDK

Dynamic SDK provides authentication and wallet features for native mobile applications.

For setup instructions and API documentation, see [Dynamic documentation](https://docs.dynamic.xyz/).

For support, contact [Dynamic support](https://www.dynamic.xyz/contact).
